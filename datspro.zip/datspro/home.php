<?php
require_once("include/initialize.php");
 if (!isset($_SESSION['ACCOUNT_ID'])){
      redirect(web_root."/index.php");
     }
     ?>
<div class="row">
         <div class="col-lg-12">
            <h1 class="page-header">Administrator's Dashboard FOR <?php echo "AY: ".$_SESSION['AY'].', '."SEM: ".$_SESSION['SEMESTER']; ?></h1>
          </div>
          <!-- /.col-lg-12 -->
       </div>
 
   
  <!-- /.panel -->

  <?php
 
$dataPoints = array( 
  array("label"=>"Chrome", "y"=>64.02),
  array("label"=>"Firefox", "y"=>12.55),
  array("label"=>"IE", "y"=>8.47),
  array("label"=>"Safari", "y"=>6.08),
  array("label"=>"Edge", "y"=>4.29),
  array("label"=>"Others", "y"=>4.59)
)
 
?>

 
<?php
    global $mydb;
      $mydb->setQuery("SELECT COUNT(`IDNO`) AS RES, CONCAT(c.COURSE_NAME, '-', c.COURSE_LEVEL) as GRADE FROM `schoolyr` s, course c WHERE c.`COURSE_ID`=s.`COURSE_ID`AND `SEMESTER`='{$_SESSION['SEMESTER']}' AND  `AY`='{$_SESSION['AY']}' and `CATEGORY`='Enrolled' GROUP BY s.`COURSE_ID`");
      $cur = $mydb->loadResultList();
      $mydb->setQuery("SELECT COUNT(`IDNO`) AS RES, CONCAT(c.COURSE_NAME, '-', c.COURSE_LEVEL) as GRADE FROM `schoolyr` s, course c WHERE c.`COURSE_ID`=s.`COURSE_ID`AND `SEMESTER`='{$_SESSION['SEMESTER']}' AND  `AY`='{$_SESSION['AY']}' and `CATEGORY`='Enrolled'");
      $NoOfResultGRADE = $mydb->loadSingleResult();
   
      $dataPointsGRADE = array();    
      foreach ( $cur as $resultG) {
       
         $elementsGRADE = array("label"=>$resultG->GRADE, "y" =>(($resultG->RES / $NoOfResultGRADE->RES) * 100));
        array_push($dataPointsGRADE, $elementsGRADE);
    
       } 

       $mydb->setQuery("SELECT COUNT(`IDNO`) AS RES, c.COURSE_LEVEL as LEVEL FROM `schoolyr` s, course c WHERE c.`COURSE_ID`=s.`COURSE_ID`AND `SEMESTER`='{$_SESSION['SEMESTER']}' AND  `AY`='{$_SESSION['AY']}' and `CATEGORY`='Enrolled' GROUP BY c.COURSE_LEVEL");
      $curlevel = $mydb->loadResultList();

      $mydb->setQuery("SELECT COUNT(`IDNO`) AS G FROM `schoolyr` s, course c WHERE c.`COURSE_ID`=s.`COURSE_ID`AND `SEMESTER`='{$_SESSION['SEMESTER']}' AND  `AY`='{$_SESSION['AY']}' and `CATEGORY`='Enrolled'");
      $NoOfResultLVL = $mydb->loadSingleResult();

      $dataPointsLEVEL = array();    
      foreach ($curlevel as $resultlvl) {
        if ($resultlvl->LEVEL == '11') {
           $elementsLEVEL = array("label" =>"G-11", "y" =>(($resultlvl->RES / $NoOfResultLVL->G) * 100));
        }elseif ($resultlvl->LEVEL == '12') {
         $elementsLEVEL = array("label" =>"G-12", "y" =>(($resultlvl->RES / $NoOfResultLVL->G) * 100));
        }
       
        array_push($dataPointsLEVEL, $elementsLEVEL);
    
       } 


      $mydb->setQuery("SELECT SEX , COUNT(`SEX`) as S FROM `tblstudent` GROUP by `SEX`");
      $cur1 = $mydb->loadResultList();

      $mydb->setQuery("SELECT COUNT(`SEX`) as G FROM `tblstudent`");
      $NoOfResult = $mydb->loadSingleResult();

      $dataPoints2 = array();    
      foreach ( $cur1 as $result) {
        if ($result->SEX == 'F') {
           $elements = array("label" =>"Female", "y" =>(($result->S / $NoOfResult->G) * 100));
        }elseif ($result->SEX == 'M') {
         $elements = array("label" =>"Male", "y" => (($result->S / $NoOfResult->G) * 100));
        }
       
        array_push($dataPoints2, $elements);
    
       } 
 

?>
<script>
window.onload = function() {
 
 
var chart = new CanvasJS.Chart("chartContainer1", {
  animationEnabled: true,
  title: {
    text: "Student Enrolled per Strand"
  },
  subtitles: [{
    text: "November 2018"
  }],
  data: [{
    type: "pie",
    yValueFormatString: "#,##0.00\"%\"",
    indexLabel: "{label} ({y})",
    dataPoints: <?php echo json_encode($dataPointsGRADE, JSON_NUMERIC_CHECK); ?>
  }]
});
chart.render();
var chart = new CanvasJS.Chart("chartContainer2", {
  animationEnabled: true,
  title: {
    text: "Gender"
  },
  subtitles: [{
    text: "As of November 2018"
  }],
  data: [{
    type: "pie",
    yValueFormatString: "#,##0.00\"%\"",
    indexLabel: "{label} ({y})",
    dataPoints: <?php echo json_encode($dataPoints2, JSON_NUMERIC_CHECK); ?>
  }]
});
chart.render();

var chart = new CanvasJS.Chart("chartContainer", {
  animationEnabled: true,
  title: {
    text: "Student Enrolled per Level"
  },
  data: [{
    type: "pie",
    startAngle: 240,
    yValueFormatString: "##0.00'%'",
    indexLabel: "{label} {y}",
    dataPoints: <?php echo json_encode($dataPointsLEVEL, JSON_NUMERIC_CHECK); ?>
  }]
});
chart.render();

}
</script>

                  
 <div class="row">
  <div class="col-lg-3">
  <div class="card-header"><i class="fa fa-pie-chart"></i> </div>
        <div class="card-body">
         <div id="chartContainer1" style="height: 370px; width: 100%;"></div>
        </div>
        <div class="card-footer small text-muted"></div>
    
  </div> 
  <div class="col-lg-3">
   <div class="card-header"><i class="fa fa-pie-chart"></i>
   
   </div>
        <div class="card-body">
         <div id="chartContainer" style="height: 370px; width: 100%;"></div>
        </div>
        <div class="card-footer small text-muted"></div>
    
  </div>  
   
  <div class="col-lg-4">
     
      <div class="card-header"><i class="fa fa-pie-chart"></i> Pie Chart Example</div>
        <div class="card-body">
         <div id="chartContainer2" style="height: 370px; width: 100%;"></div>
        </div>
        <div class="card-footer small text-muted"></div>

  </div>  
 </div>        
  