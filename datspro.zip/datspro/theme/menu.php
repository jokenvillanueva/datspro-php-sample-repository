<ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="<?php echo WEB_ROOT; ?>index.php">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Dashboard</span>
          </a>
        </li>
         <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Example Pages">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseExamplePages" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-file"></i>
            <span class="nav-link-text">Entry</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseExamplePages">
            <li>
              <a href="<?php echo WEB_ROOT; ?>module/student/">Student Module</a>
            </li>
            <li>
              <a href="<?php echo WEB_ROOT; ?>module/subject/">Subject Module</a>
            </li>
            <li>
              <a href="<?php echo WEB_ROOT; ?>module/Strand/">Strand Module</a>
            </li>
            <li>
             <a href="<?php echo WEB_ROOT; ?>module/faculty/">Faculty Module</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Charts">
          <a class="nav-link" href="<?php echo WEB_ROOT; ?>module/enrollment/">
            <i class="fa fa-fw fa-area-chart"></i>
            <span class="nav-link-text">Enrollment</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Tables">
          <a class="nav-link" href="<?php echo WEB_ROOT; ?>module/facultyloading/">
            <i class="fa fa-fw fa-table"></i>
            <span class="nav-link-text">Faculty Loading</span>
          </a>
        </li>
       <!--  <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Tables">
          <a class="nav-link" href="<?php echo WEB_ROOT; ?>module/Scheduling/">
            <i class="fa fa-fw fa-gear"></i>
            <span class="nav-link-text">Scheduling</span>
          </a>
        </li> -->
         <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Charts">
          <a class="nav-link" href="<?php echo WEB_ROOT; ?>module/attendance/">
            <i class="fa fa-fw fa-area-chart"></i>
            <span class="nav-link-text">Attendance</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Components">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseComponents" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-wrench"></i>
            <span class="nav-link-text">Settings</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseComponents">
            <li>
              <a href="<?php echo WEB_ROOT; ?>module/Settings/">Default</a>
            </li>
            <li>
              <a href="<?php echo WEB_ROOT; ?>module/room/">Room</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Components">
          <a class="nav-link"  href="<?php echo WEB_ROOT; ?>module/user/">
            <i class="fa fa-fw fa-user"></i>
            <span class="nav-link-text">User</span>
          </a>
          
        </li>
      
       
      </ul>