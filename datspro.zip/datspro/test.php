
<html>
  <head>
    <title>PHP Syntax</title>
  </head>
  <body>
    <?php
      echo "PHP Programming is fun!";
    ?>
  </body>
</html>