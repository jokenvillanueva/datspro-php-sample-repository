<?php
	 if (!isset($_SESSION['ACCOUNT_ID'])){
      redirect(web_root."admin/index.php");
     }

?>

<script type="text/javascript">
	$(document).ready(function() {
    $('#example').DataTable( {
      paging:         false
    } );
} );
</script>

 <div class="card mb-3">

        <div class="card-header">
          <i class="fa fa-table"></i> List of Students   <a href="index.php?view=add" class="btn btn-primary  ">  <i class="fa fa-plus-circle fw-fa"></i> New</a></div>

         
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
             <thead>
				  	<tr>
				  		<th>ID#.</th>
				  		<th>Fullname</th>
				  		<th>Gender</th>
				  		<th>Age</th>
				  		<th>Birth Date</th>
				  		<th>Religion</th>
				  		<th>RFID Code</th>
				  		<th width="20%">Action</th>
				  	</tr>	
				  </thead>
				  	<?php 

				  	global $mydb;
				

				  	  //`S_ID`, `IDNO`, `FNAME`, `LNAME`, `MNAME`, `SEX`, `BDAY`, `WEIGHT`, `HEIGHT`, `AGE`, `SIBLINGS`, `RELIGION`, `RFIDCODE`, `HOME_ADD`, `POSITION`
				  	  	$mydb->setQuery("SELECT  `IDNO` , CONCAT(  `LNAME` ,  ' ',  `FNAME` ,  ' ',  `MNAME` ) AS  'Name',
				  						  `SEX` ,`AGE`, `BDAY` ,  `RELIGION` ,  `RFIDCODE`
				  						  FROM  `tblstudent` ");
				  	  	loadresult();

				  	  	function loadresult(){
				  			global $mydb;
					  		$cur = $mydb->loadResultList();
							foreach ($cur as $student) {
					  		echo '<tr>';

					  		echo '<td>'. $student->IDNO.'</a></td>';
					  		echo '<td>'. $student->Name.'</td>';
					  		echo '<td>'. $student->SEX.'</td>';
					  		echo '<td>'. $student->AGE.'</td>';
					  		echo '<td>'. $student->BDAY.'</td>';
					  		echo '<td>'. $student->RELIGION.'</td>';
					  		echo '<td>'. $student->RFIDCODE.'</td>';
					  		$active = "disabled";
				  		
					  		echo '<td align="center" > 
					  			<a title="Edit" href="index.php?view=edit&id='.$student->IDNO.'"  class="btn btn-primary btn-xs  ">  <span class="fa fa-edit fw-fa"></span></a>
					  			<a title="Image" href="index.php?view=editpic&id='.$student->IDNO.'" class="btn btn-success btn-xs" '.$active.'><span class="fa fa-picture-o fw-fa"></span> </a>
					  			<a title="Delete" href="controller.php?action=delete&id='.$student->IDNO.'" class="btn btn-danger btn-xs" '.$active.'><span class="fa fa-trash-o fw-fa"></span> </a>
					  			</td>';
					  		echo '</tr>';
					  		}

				  		} 
				  	  	?>
            
              <tbody>
  			 </tbody>
            </table>
          </div>
        </div>
      
      </div>