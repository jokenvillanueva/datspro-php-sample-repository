<?php
require_once ("../../include/initialize.php");
	  if (!isset($_SESSION['ACCOUNT_ID'])){
      redirect(web_root."admin/index.php");
     }

$action = (isset($_GET['action']) && $_GET['action'] != '') ? $_GET['action'] : '';

switch ($action) {
	case 'add' :
	doInsert();
	break;
	
	case 'edit' :
	doEdit();
	break;
	
	case 'delete' :
	doDelete();
	break;

	case 'editpic' :
	doupdateimage();
	break;

 
	}
   
	function doInsert(){
	
 //`S_ID`, `IDNO`, `FNAME`, `LNAME`, `MNAME`, `SEX`, `BDAY`, `WEIGHT`, `HEIGHT`, 
 //`AGE`, `SIBLINGS`, `RELIGION`, `RFIDCODE`, `HOME_ADD`, `POSITION`


	//primary Details
$IDNO  = $_POST['idno'];
$FNAME = $_POST['fName'];
$LNAME = $_POST['lName'];
$MNAME = $_POST['mName'];
$MI = $_POST['MI'];
$SEX   = $_POST['gender'];
$BDAY  = $_POST['bday'];
$WEIGHT= $_POST['Weight'];
$HEIGHT= $_POST['Height'];
$AGE   = $_POST['age'];
$SIBLINGS = $_POST['Siblings'];
$RELIGION = $_POST['religion'];
$RFIDCODE = $_POST['rfid'];
$HOME_ADD = $_POST['HOME_ADD'];
$POSITION   = $_POST['Position'];
$BRGY 		= $_POST['brgy'];
$CITY 		= $_POST['city'];
$PROVINCE 	= $_POST['province'];


$student = new Student();
//$student->S_ID				= "null";
$student->IDNO 				=	$IDNO;
$student->LNAME				=	$LNAME;
$student->FNAME				=	$FNAME;
$student->MNAME				=	$MNAME;
$student->MI				=	$MI;
$student->SEX				=	$SEX;
$student->BDAY				=	$BDAY;
$student->WEIGHT			=	$WEIGHT;
$student->HEIGHT			=	$HEIGHT;
$student->AGE				=	$AGE;
$student->SIBLINGS			=	$SIBLINGS;
$student->RELIGION			=	$RELIGION;
$student->RFIDCODE			=	$RFIDCODE;
$student->HOME_ADD			=	$HOME_ADD;
$student->POSITION 			=	$POSITION;
$student->BRGY				=	$BRGY;
$student->CITY				=	$CITY;
$student->PROVINCE			=	$PROVINCE;
//course infor
/*$course	= $_POST['course'];
$semester = $_POST['semester'];
$ay		= $_POST['AY'];
$sy = new Schoolyr();
$sy->AY 		= $ay;
$sy->SEMESTER 	= $semester;
$sy->COURSE_ID	= $course;
$sy->IDNO 		= $IDNO;*/
/*if ($istrue) {
	output_message('course info successfully added!');
	redirect ('newstudent.php');
}

*/  
//secondary Details
$FATHER 			= $_POST['father'];
$FATHER_OCCU 		= $_POST['fOccu'];
$MOTHER 			= $_POST['mother'];
$MOTHER_OCCU 		= $_POST['mOccu'];
$BOARDING 			= $_POST['boarding'];
$WITH_FAMILY 		= $_POST['withfamily'];
$GUARDIAN 			=  $_POST['guardian'];
$GUARDIAN_ADDRESS 	=  $_POST['guardianAdd'];
$OTHER_PERSON_SUPPORT = $_POST['lastschool'];
$ADDRESS 			=  $_POST['Address'];
$GWA 	 			=  $_POST['gwa'];

$studdetails = new Student_details();
$studdetails->FATHER				=	$FATHER;
$studdetails->FATHER_OCCU			=	$FATHER_OCCU;
$studdetails->MOTHER				=	$MOTHER;
$studdetails->MOTHER_OCCU			=	$MOTHER_OCCU;
$studdetails->BOARDING			    =	$BOARDING;
$studdetails->WITH_FAMILY			=	$WITH_FAMILY;
$studdetails->GUARDIAN			    =	$GUARDIAN;
$studdetails->GUARDIAN_ADDRESS		=	$GUARDIAN_ADDRESS;
$studdetails->OTHER_PERSON_SUPPORT	=	$OTHER_PERSON_SUPPORT;
$studdetails->ADDRESS				=	$ADDRESS;
$studdetails->IDNO 				    =	$IDNO;
$studdetails->GWA 				    =	$GWA;

//  
/*if ($istrue) {
	output_message('Seccondary details successfully added!');
	redirect ('index.php?view=add');
}
*/
//requirements
/*$nso  				  = isset($_POST['nso']) ? "Yes" : "No";
$bapt 				  = isset($_POST['baptismal']) ? "Yes" : "No";
$entrance 			  = isset($_POST['entrance']) ? "Yes" : "No";
$mir_contract  		  = isset($_POST['mir_contract']) ? "Yes" : "No";
$certifcateOfTransfer = isset($_POST['certifcateOfTransfer']) ? "Yes" : "No";

$requirements = new Requirements();

$requirements->NSO				 		= $nso;
$requirements->BAPTISMAL		   		= $bapt;
$requirements->ENTRANCE_TEST_RESULT		= $entrance;
$requirements->MARRIAGE_CONTRACT        = $mir_contract;
$requirements->CERTIFICATE_OF_TRANSFER	= $certifcateOfTransfer;
$requirements->IDNO 			   		= $IDNO;
*///$istrue = $requirements->create(); 
/*if ($istrue) {
	output_message('Student requirements successfully added!');
	redirect ('newstudent.php');
} 
*/

if ($IDNO == "") {
	message('ID Number is required!', "error");
	redirect ('index.php?view=add');
}elseif ($LNAME == "") {
	message('Last Name is required!', "error");
	redirect ('index.php?view=add');
}elseif ($FNAME == "") {
	message('First Name is required!', "error");
	redirect ('index.php?view=add');
}elseif ($MNAME == "") {
	message('Middle Name is required!', "error");
	redirect ('newstudent.php');
}elseif ($GUARDIAN_ADDRESS == "") {
	message('Contact Number is required!', "error");
	redirect ('index.php?view=add');
	
}else{

$istrue = 	$student->create(); 
	#$sy->create();  
$istrue1 =	$studdetails->create();
	//$requirements->create(); 


			if ($istrue == 1 AND $istrue1 == 1){
						 
				message('New student ['. $FNAME .' '. $LNAME .'] addedd successfully!', "success");
				redirect('index.php');	

			 }else{
			 	message('No record has been addedd!', "error");
				redirect('index.php');	

			 }

}


	}

	function doEdit(){
	if (isset($_POST['save'])){	

	//primary Details
$IDNO  = $_POST['idno'];
$FNAME = $_POST['fName'];
$LNAME = $_POST['lName'];
$MNAME = $_POST['mName'];
$MI    = $_POST['MI'];
$SEX   = $_POST['gender'];
$BDAY  = $_POST['bday'];
$WEIGHT= $_POST['Weight'];
$HEIGHT= $_POST['Height'];
$AGE   = $_POST['age'];
$SIBLINGS = $_POST['Siblings'];
$RELIGION = $_POST['religion'];
$RFIDCODE = $_POST['rfid'];
$HOME_ADD = $_POST['HOME_ADD'];
$POSITION   = $_POST['Position'];
$BRGY 		= $_POST['brgy'];
$CITY 		= $_POST['city'];
$PROVINCE 	= $_POST['province'];

$student = new Student();
//$student->S_ID				= "null";
$student->IDNO 				=	$IDNO;
$student->LNAME				=	$LNAME;
$student->FNAME				=	$FNAME;
$student->MNAME				=	$MNAME;
$student->MI				=	$MI;
$student->SEX				=	$SEX;
$student->BDAY				=	$BDAY;
$student->WEIGHT			=	$WEIGHT;
$student->HEIGHT			=	$HEIGHT;
$student->AGE				=	$AGE;
$student->SIBLINGS			=	$SIBLINGS;
$student->RELIGION			=	$RELIGION;
$student->RFIDCODE			=	$RFIDCODE;
$student->HOME_ADD			=	$HOME_ADD;
$student->POSITION 			=	$POSITION;
$student->BRGY				=	$BRGY;
$student->CITY				=	$CITY;
$student->PROVINCE			=	$PROVINCE;
//course infor
/*$course	= $_POST['course'];
$semester = $_POST['semester'];
$ay		= $_POST['AY'];
$sy = new Schoolyr();
$sy->AY 		= $ay;
$sy->SEMESTER 	= $semester;
$sy->COURSE_ID	= $course;
$sy->IDNO 		= $IDNO;*/
/*if ($istrue) {
	output_message('course info successfully added!');
	redirect ('newstudent.php');
}

*/  
//secondary Details
$FATHER 			= $_POST['father'];
$FATHER_OCCU 		= $_POST['fOccu'];
$MOTHER 			= $_POST['mother'];
$MOTHER_OCCU 		= $_POST['mOccu'];
$BOARDING 			= $_POST['boarding'];
$WITH_FAMILY 		= $_POST['withfamily'];
$GUARDIAN 			=  $_POST['guardian'];
$GUARDIAN_ADDRESS 	=  $_POST['guardianAdd'];
$OTHER_PERSON_SUPPORT = $_POST['lastschool'];
$ADDRESS 			=  $_POST['Address'];
$GWA 	 			=  $_POST['gwa'];

$studdetails = new Student_details();
$studdetails->FATHER				=	$FATHER;
$studdetails->FATHER_OCCU			=	$FATHER_OCCU;
$studdetails->MOTHER				=	$MOTHER;
$studdetails->MOTHER_OCCU			=	$MOTHER_OCCU;
$studdetails->BOARDING			    =	$BOARDING;
$studdetails->WITH_FAMILY			=	$WITH_FAMILY;
$studdetails->GUARDIAN			    =	$GUARDIAN;
$studdetails->GUARDIAN_ADDRESS		=	$GUARDIAN_ADDRESS;
$studdetails->OTHER_PERSON_SUPPORT	=	$OTHER_PERSON_SUPPORT;
$studdetails->ADDRESS				=	$ADDRESS;
$studdetails->IDNO 				    =	$IDNO;
$studdetails->GWA 				    =	$GWA;

//  
/*if ($istrue) {
	output_message('Seccondary details successfully added!');
	redirect ('newstudent.php');
}
*/

//requirements
/*$nso  				  = isset($_POST['nso']) ? "Yes" : "No";
$bapt 				  = isset($_POST['baptismal']) ? "Yes" : "No";
$entrance 			  = isset($_POST['entrance']) ? "Yes" : "No";
$mir_contract  		  = isset($_POST['mir_contract']) ? "Yes" : "No";
$certifcateOfTransfer = isset($_POST['certifcateOfTransfer']) ? "Yes" : "No";

$requirements = new Requirements();

$requirements->NSO				 		= $nso;
$requirements->BAPTISMAL		   		= $bapt;
$requirements->ENTRANCE_TEST_RESULT		= $entrance;
$requirements->MARRIAGE_CONTRACT        = $mir_contract;
$requirements->CERTIFICATE_OF_TRANSFER	= $certifcateOfTransfer;
$requirements->IDNO 			   		= $IDNO;*/
//$istrue = $requirements->create(); 
/*if ($istrue) {
	output_message('Student requirements successfully added!');
	redirect ('newstudent.php');
} 
*/

if ($IDNO == "") {
	message('ID Number is required!', "error");
	redirect ('index.php?view=edit?id='.$IDNO);
}elseif ($LNAME == "") {
	message('Last Name is required!', "error");
	redirect ('index.php?view=edit?id='.$IDNO);
}elseif ($FNAME == "") {
	message('First Name is required!', "error");
redirect ('index.php?view=edit?id='.$IDNO);
}elseif ($MNAME == "") {
	message('Middle Name is required!', "error");
	redirect ('index.php?view=edit?id='.$IDNO);
}elseif ($GUARDIAN_ADDRESS == "") {
	message('Email address is required!', "error");
redirect ('index.php?view=edit?id='.$IDNO);
	
}else{

	$student->update($IDNO); 
	//$sy->update($_GET['id']);  
	$studdetails->update($IDNO);
	//$requirements->update($IDNO); 
	message('Student infomation updated successfully!', "info");
	redirect('index.php');	


}
}
	}


	function doDelete(){
		
		// if (isset($_POST['selector'])==''){
		// message("Select the records first before you delete!","info");
		// redirect('index.php');
		// }else{

		// $id = $_POST['selector'];
		// $key = count($id);

		// for($i=0;$i<$key;$i++){

		// 	$user = New User();
		// 	$user->delete($id[$i]);

		
				$id = 	$_GET['id'];

				$user = New User();
	 		 	$user->delete($id);
			 
			message("User already Deleted!","info");
			redirect('index.php');
		// }
		// }

		
	}

	function doupdateimage(){
 
		if (!isset($_FILES['image']['tmp_name'])) {
			message("No Image Selected!", "error");
			redirect("index.php?view=list");
		}else{
			$file=$_FILES['image']['tmp_name'];
			$image= addslashes(file_get_contents($_FILES['image']['tmp_name']));
			$image_name= addslashes($_FILES['image']['name']);
			$image_size= getimagesize($_FILES['image']['tmp_name']);
			
			if ($image_size==FALSE) {
				message("That's not an image!");
				redirect("index.php?view=list");
		   }else{
			
				$IDNO  = $_POST['id'];
				$location="photos/".$_FILES["image"]["name"];
				

	 				/*$rm = new Room();
	          		$rm_id = $_POST['id'];*/
				
			    	move_uploaded_file($_FILES["image"]["tmp_name"],"photos/".$_FILES["image"]["name"]);
					
				//	$rm->roomImage = $location;
					/*$_POST = array();
					$rm->update_room($rm_id); */
					global $mydb; 
                      $mydb->setQuery("INSERT INTO photo (`FILENAME`, `IDNO`) VALUES('{$location}','{$IDNO}')");
                      $mydb->executeQuery(); 	
				 	message("Student Image Updated successfully!", "success");
				
				 	redirect("index.php");
 			}
 		}
			 
		}
 
?>