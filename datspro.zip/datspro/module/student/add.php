                      <?php 
                        if (!isset($_SESSION['ACCOUNT_ID'])){
                          redirect(web_root."admin/index.php");
                         }

                 
                       ?> 
 <div class="container">
    <div class="card card-register mx-auto mt-2">
      <div class="card-header">Register New Student</div>
      <div class="card-body">
        <form action="controller.php?action=add" method="POST">


          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                 <label for="idno">LRN :</label>
                 <input class="form-control" id="idno" name="idno" placeholder="Learners Registered Number" type="number" value="" required min="11">
              </div>
              <div class="col-md-6">
               <label for="rfid">RFID Code : </label>
                <input class="form-control" id="rfid" name="rfid" placeholder="RFID Code" type="number" value="" required>
              </div>
            </div>
          </div>

           <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="lName">LastName</label>
                <input class="form-control " id="lName" name="lName" type="text" placeholder="Last Name" required>
              </div>
              <div class="col-md-4">
               <label for="fName">Firstname </label>
                <input class="form-control " id="fName" name="fName" type="text" placeholder="First Name" required>
              </div>
               <div class="col-md-4">
               <label for="mName">Middlename </label>
                 <input class="form-control" id="mName" name="mName" type="text" placeholder="Middle Name" required>
              </div>
            </div>
          </div>  
          <div class="form-group">
            <div class="form-row">
               <div class="col-md-4">
               <label for="MI">Middle Initial </label>
                
                   <input class="form-control " id="MI" name="MI" type="text" placeholder="MI" required>
              </div>
              <div class="col-md-4">
                <label for="bday">Birth Date</label>
                <div class="input-group date form_curdate col-md-15" data-date="" data-date-format="yyyy-mm-dd" data-link-field="any" data-link-format="yyyy-mm-dd">
                <input class="form-control" size="11" type="date" value="" data-date-format="yyyy-mm-dd" name="bday" id="bday">
                
                      </div>
              </div>
              <div class="col-md-4">
               <label for="gender">Gender : </label>
                <select class="form-control input-sm" name="gender" id="gender">
                    <option value="M">Male</option>
                    <option value="F">Female</option> 
                  </select>
              </div>
              
            </div>
          </div>
           <div class="form-group">
            <div class="form-row">
               <div class="col-md-4">
               <label for="age">Age : </label>
                 <input class="form-control input-sm" id="age" name="age" type="number" min="0" placeholder="age" required>
              </div>
              <div class="col-md-4">
                <label for="Weight">Weight (kg)</label>
                <input class="form-control" id="Weight" name="Weight" type="number" min="0" placeholder="Weight(kg)" required>
              </div>
              <div class="col-md-4">
               <label for="Height">Height (cm) </label>
               <input class="form-control " id="Height" name="Height" min="0" type="number" placeholder="Height" required>
              </div>
              
            </div>
          </div>   
           <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="Siblings">Siblings</label>
                  <input class="form-control" id="Siblings" name="Siblings" type="number"  min="0" placeholder="Number of Siblings" required>
              </div>
              <div class="col-md-4">
               <label for="Position">Position</label>
               <select class="form-control input-sm" name="Position" id="Position">
                    <option value="1st">1st</option>
                    <option value="2nd">2nd</option> 
                    <option value="3rd">3rd</option>
                    <option value="4th">4th</option>
                    <option value="5th">5th</option> 
                    <option value="6th">6th</option>
                    <option value="7th">7th</option>
                    <option value="8th">8th</option> 
                    <option value="9th">9th</option>
                    <option value="10th">10th</option>
                  </select> 
              </div>
               <div class="col-md-4">
               <label for="religion">Religion </label>
                 <select class="form-control input-sm" name="religion" id="religion">
                    <option value="Christianity">Christianity</option>
                    <option value="Muslim">Muslim</option> 
                    <option value="Others">Others</option> 
                  </select> 
              </div>
            </div>
          </div>  
            <div class="form-group">
            <div class="form-row">
                <div class="col-md-6">
               <label for="province">Province : </label>

                <select class="form-control input-sm action" name="province" id="province">
                    <?php 
             
                      global $mydb;
                      $mydb->setQuery("SELECT DISTINCT(`PROVINCE`) FROM `tblplace`");
                      $cur = $mydb->loadResultList();
                      $output .= '<option value="">Select Province</option>';
                      foreach ($cur as $prov) {
                           $output .= '<option value="'. utf8_encode($prov->PROVINCE).'">'.utf8_encode($prov->PROVINCE).'</option>';
                        }
                        echo $output;
                      ?>
                  
                  </select>
              </div>
              <div class="col-md-6">
               <label for="city">City/Town/Mun. : </label>
                <select class="form-control input-sm action" name="city" id="city">
                                   
                  </select>
              </div>
             
                          
              
            </div>
          </div> 
           <div class="form-group">
            <div class="form-row">
               <div class="col-md-6">
               <label for="brgy">Baranggay : </label>
               <select class="form-control input-sm" name="brgy" id="brgy">
          
                  </select>
              </div>
                <div class="col-md-6">
               <label for="HOME_ADD">House Number/Zone : </label>
                <input type="text" class="form-control input-sm" name="HOME_ADD" id="HOME_ADD">
                    
              </div>
            
          
            </div>
          </div>

            <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                 <label for="father">Father </label>
                 <input class="form-control" id="father" name="father" type="text" placeholder="Father" required>
              </div>
              <div class="col-md-6">
               <label for="fOccu">Occupation</label>
                 <input class="form-control" id="fOccu" name="fOccu" type="text" placeholder="Occupation" required>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                 <label for="mother">Mother </label>
                 <input class="form-control" id="mother" name="mother" type="text" placeholder="Mother" required>
              </div>
              <div class="col-md-6">
               <label for="mOccu">Occupation</label>
                 <input class="form-control" id="mOccu" name="mOccu" type="text" placeholder="Occupation" required>
              </div>
            </div>
          </div>
           <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                 <label for="boarding">Are you Boarding?  </label>
                      <div class="radio">
                        <label><input checked id="boarding"name="boarding" type="radio" value="Yes">Yes</label>
                      </div>
                      <div class="radio">
                        <label><input checked id="boarding" name="boarding" type="radio" value="No">No</label>
                      </div>
              </div>
              <div class="col-md-6">
               <label for="withfamily">With Family?</label>
                    <div class="radio">
                      <label><input checked id="withfamily" name="withfamily" type="radio" value="Yes">Yes</label>
                    </div>
                    <div class="radio">
                      <label><input checked id="withfamily" name="withfamily" type="radio" value="No">No</label>
                    </div>
              </div>
            </div>
          </div>

            <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                 <label for="guardian">Guardian </label>
                 <input class="form-control" id="guardian" name="guardian" type="text" placeholder="Guardian" required>
              </div>
              <div class="col-md-6">
               <label for="guardianAdd">Contact No.</label>
                 <input class="form-control" id="guardianAdd" name="guardianAdd"  type="number" placeholder="Guardian/Parent Contact Number" required oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"  maxlength = "11">
              </div>
            </div>
          </div>
              
                 <div class="form-group">
                  <div class="form-row">
                    <div class="col-md-12">
                       <label for="lastschool">Last School Attended </label>
                       <input class="form-control" id="lastschool" name="lastschool" type="text" placeholder="Last School Attended" required>
                    </div>
                   
                  </div>
                </div>
                 <div class="form-group">
                  <div class="form-row">
                    <div class="col-md-12">
                       <label for="Address">Complete Address </label>
                       <input class="form-control" id="Address" name="Address" type="text" placeholder="Complete Address" required>
                    </div>
                   
                  </div>
                </div>
                  <div class="form-group">
                  <div class="form-row">
                    <div class="col-md-12">
                       <label for="gwa">General Average </label>
                      <input class="form-control" id="gwa"  name="gwa" type="number" placeholder="General Average" required  oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"  maxlength = "2">
                    </div>
                   
                  </div>
                </div>
        
          

         
         
         <!--  <a class="btn btn-primary btn-block" href="login.html">Register</a> -->
           <button class="btn btn-primary btn-block" name="save" type="submit" ><span class="glyphicon glyphicon-floppy-save"></span> Register</button>
        </form>
      
      </div>
    </div>
  </div>
  