<?php  
      if (!isset($_SESSION['ACCOUNT_ID'])){
      redirect(web_root."admin/index.php");
     }


$student = new Student();
$cur = $student->single_student($_GET['id']);

?> 
<?php  
      if (!isset($_SESSION['ACCOUNT_ID'])){
      redirect(web_root."admin/index.php");
     }
global $mydb; 
$mydb->setQuery("SELECT * FROM PHOTO WHERE IDNO='{$_GET['id']}'");
$rowcount = $mydb->num_rows();
if ($rowcount > 0){
 
 $cur= $mydb->loadSingleResult();
 $location = $cur->FILENAME;
}else{
$location = 'photos/defaultimg.png';
}
/*$student = new Student();
$cur = $student->single_student($_GET['id']);*/

?> 

  <div class="container">
    <div class="card card-register mx-auto mt-2">
      <div class="card-header">Upload Student Image</div>
      <div class="card-body">
        <form action="controller.php?action=editpic" enctype="multipart/form-data" method="POST">

            <table class="table table-hover" border="0" width="50">
            			
            		<tr>
            		<td width="80">
            			<input name="id" type="hidden" value="<?php echo $_GET['id'];  ?>">
            			<img src="<?php echo $location;?>" width="300" height="300" /></td>
            		</tr>

            		<tr>
            		<td width="80">
            			<input id="image" name="image" type="file"></td>
            		</tr>
    	
    	
    		  </table>
   
         
         <!--  <a class="btn btn-primary btn-block" href="login.html">Register</a> -->
           <button class="btn btn-primary btn-block" name="save" type="submit" ><span class="glyphicon glyphicon-floppy-save"></span> Upload</button>
        </form>
      
      </div>
    </div>
  </div>