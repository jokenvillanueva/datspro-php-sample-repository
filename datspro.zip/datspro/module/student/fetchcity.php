<?php
require_once("../../include/initialize.php");

if(isset($_POST["action"]))
{
 //echo //htmlentities($_POST['query']);
 $output = '';

 if($_POST["action"] == "province")
 {
  global $mydb;
  $mydb->setQuery("SELECT DISTINCT(`CITY`) FROM `tblplace` WHERE `PROVINCE`='". ($_POST['query'])."'");
  $cur = $mydb->loadResultList();
  $output .= '<option value="">Select City/Municipalities/Town</option>';
  foreach ($cur as $prov) {
       $output .= '<option value="'. utf8_encode($prov->CITY).'">'.utf8_encode($prov->CITY).'</option>';
    }
   }

 if($_POST["action"] == "city")
 {
  $city = utf8_decode($_POST['query']);
  echo $city;
    global $mydb;
  $mydb->setQuery("SELECT `BRGY` FROM `tblplace` WHERE `CITY`='".$city."' ");
  $curs = $mydb->loadResultList();
  $output .= '<option value="">Select Baranggay</option>';
  foreach ($curs as $brgy) {
       $output .= '<option value="'. utf8_encode($brgy->BRGY).'">'.utf8_encode($brgy->BRGY).'</option>';
    }
 }

 echo $output;

}
?>