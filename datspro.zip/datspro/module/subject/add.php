<?php 
  if (!isset($_SESSION['ACCOUNT_ID'])){
    redirect(web_root."admin/index.php");
   }


 ?> 
 <div class="container">
    <div class="card card-register mx-auto mt-2">
      <div class="card-header">Add new Subject</div>
      <div class="card-body">
        <form action="controller.php?action=add" method="POST">
          <div class="form-group">
            <div class="form-row">
              <div class="col-md">
                <label for="subjcode">Subject Code</label>
                <input class="form-control" id="subjcode" name="subjcode" type="text" placeholder="Subject Code" required>
              </div>
             
            </div>
          </div>
          <div class="form-group">
            <label for="subjdesc">Subject Description</label>
            <input class="form-control" id="subjdesc" name="subjdesc" placeholder="Subject Description" type="text" required>
          </div>
          <div class="form-group">
            <label for="unit">No of units</label>
            <input class="form-control" id="unit" name="unit" placeholder="No of units" type="number" required>
          </div>
          <div class="form-group">
            <label for="pre">Prerequisite</label>

            <input class="form-control" id="pre" name="pre" placeholder="Prerequisite" type="text" type="text" required>
          </div>
            <div class="form-group">
              <label for="course">Course/Yr</label>

              <select class="form-control input-sm" name="course" id="course">
                 <?php
                $course = new Course();
                $cur = $course->listOfcourse(); 
                foreach ($cur as $course) {
                  echo '<option value="'. $course->COURSE_ID.'">'.$course->COURSE_NAME. '-' .$course->COURSE_LEVEL.'</option>';
                }

                ?>
            
              </select> 
            </div>
         

          <div class="form-group">
            
              <label for="ay">Academic Year</label>

              <select class="form-control input-sm" name="ay" id="ay">
                <option value="2013-2014">2013-2014</option>
                <option value="2014-2015">2014-2015</option>
                <option value="2015-2016">2015-2016</option>
                <option value="2016-2017">2016-2017</option>
                <option value="2017-2018">2017-2018</option>
                <option value="2018-2019">2018-2019</option>
                <option value="2019-2020">2019-2020</option>  
              </select> 
             
           
          </div>
          <div class="form-group">
          
              <label for="Semester">Semester</label>

             
               <select class="form-control" name="Semester" id="Semester">
                <option value="First">First</option>
                <option value="Second">Second</option>  
                <option value="Second">Summer</option>  
              </select>
              </div>
            
          </div>
         
      
        <button class="btn btn-primary btn-block" name="save" type="submit" ><span class="glyphicon glyphicon-floppy-save"></span> Save Subject</button>
        </form>
      
      </div>
    </div>
  </div>
 