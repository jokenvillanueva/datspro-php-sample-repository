<?php

$subjid = $_GET['id'];
$singlesubject = new Subject();
$object = $singlesubject->single_subject($subjid);

?>
<div class="container">
    <div class="card card-register mx-auto mt-2">
      <div class="card-header">Edit Subject</div>
      <div class="card-body">
      <form  action="controller.php?action=edit&id=<?php echo $subjid;?>" method="POST">

		

		 <div class="form-group">
            <div class="form-row">
              <div class="col-md">
          <label  for="subjcode">Subject Code</label>
       
              <input type="hidden" name="subjid" value="<?php echo $object->SUBJ_ID;?>">
             <input class="form-control" id="subjcode" name="subjcode" placeholder=
								  "Subject Code" type="text" value="<?php echo $object->SUBJ_CODE;?>">
          </div>
        </div>
      </div>

      <div class="form-group">
        <div class="form-row">
              <div class="col-md">
          <label  for="subjdesc">Subject Description</label>
            <input class="form-control " id="subjdesc" name="subjdesc" placeholder=
								  "Subject Description" type="text" value="<?php echo $object->SUBJ_DESCRIPTION;?>">
          </div>
        </div>
      </div>

       <div class="form-group">
         <div class="form-row">
              <div class="col-md">
          <label for="unit">No of units</label>
             <input class="form-control " id="unit" name="unit" placeholder=
								  "No of units" type="number" value="<?php echo $object->UNIT;?>">
          </div>
        </div>
      </div>
      <div class="form-group">
         <div class="form-row">
           <div class="col-md">
          <label for="pre">Prerequisite</label>
             <input class="form-control " id="pre" name="pre" placeholder=
								  "Prerequisite" type="text" value="<?php echo $object->PRE_REQUISITE;?>">
         </div>
        </div>
      </div>
       <div class="form-group">
          <div class="form-row">
             <div class="col-md">
            <label  for="course">Course/Yr</label>
             <select class="form-control"  name="course" id="course">
                	<?php
                	$course = new Course();
                	$cur = $course->listOfcourse();	
                	foreach ($cur as $course) {
                    if ($object->COURSE_ID ==$course->COURSE_ID ) {
                      echo '<option selected value="'. $course->COURSE_ID.'">'.$course->COURSE_NAME. '-' .$course->COURSE_LEVEL.'</option>';
                    }else{
                        echo '<option value="'. $course->COURSE_ID.'">'.$course->COURSE_NAME. '-' .$course->COURSE_LEVEL.'</option>';
                    }
                	
                	}

                	?>
  					
  			   	</select>	
          </div>
        </div>
      </div>
    
       <div class="form-group">
        <div class="form-row">
           <div class="col-md">
          <label  for="ay">Academic Year</label>
            <select class="form-control" name="ay" id="ay">
              <option value="<?php echo $object->AY;?>"><?php echo $object->AY;?></option>
      				<option value="2013-2014">2013-2014</option>
      				<option value="2014-2015">2014-2015</option>
      				<option value="2015-2016">2015-2016</option>
      				<option value="2016-2017">2016-2017</option>
      				<option value="2017-2018">2017-2018</option>
      				<option value="2018-2019">2018-2019</option>
      				<option value="2019-2020">2019-2020</option>	
      			</select>	
          </div>
        </div>
      </div>
	     <div class="form-group">
        <div class="form-row">
           <div class="col-md">
          <label for="Semester">Semester</label>
             <select class="form-control " name="Semester" id="Semester">
              <option value="<?php echo $object->SEMESTER;?>"><?php echo $object->SEMESTER;?></option>
        				<option value="First">First</option>
        				<option value="Second">Second</option>	
        				<option value="Second">Summer</option>	
        			</select>
		    <!-- 	  <input class="form-control input-sm" id="Semester" name="Semester" placeholder=
                      "Prerequisite" type="hidden" value="First">-->
           </div>
        </div>
      </div>
	<button class="btn btn-primary btn-block" name="save" type="submit" ><span class="glyphicon glyphicon-floppy-save"></span> Update Subject</button>
				

      </form>
      
      </div>
    </div>
  </div>