<?php

$rmid = $_GET['id'];
$room = new Room();
$object = $room->single_room($rmid);

?>
<?php
    check_message();
      
    ?>
<div class="container">
  <div class="card card-register mx-auto mt-2">
    <div class="card-header">Edit Room</div>
    <div class="card-body"> 
 <form action="controller.php?action=edit&id=<?php echo $rmid;?>" method="POST">
        <div class="form-group">
          <div class="form-row">
          <div class="col-md">
            <label for="rmname">Room Name</label>
                <input name="roomid" type="hidden" value="<?php echo $object->ROOM_ID;?>">
                         <input class="form-control input-sm" id="rmname" name="rmname" placeholder=
                            "Room Name" type="text" value="<?php echo $object->ROOM_NAME;?>" required>
                      </div>
                    </div>
                  </div>

        <div class="form-group">
          <div class="form-row">
             <div class="col-md">
               <label  for="roomdesc">Room Description</label>

                 <input class="form-control input-sm" id="roomdesc" name="roomdesc" placeholder=
                            "Room Description" type="text" value="<?php echo $object->ROOM_DESC;?>" required>
                      </div>
                    </div>
                  </div>
        <button class="btn btn-primary btn-block" name="save" type="submit" ><span class="glyphicon glyphicon-floppy-save"></span> Save Room</button>

        </form>
              </div>
    </div>
  </div>
 