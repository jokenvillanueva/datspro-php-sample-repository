<?php
		check_message();
			
		?>
<div class="card mb-3">

        <div class="card-header">
          <i class="fa fa-table"></i> List of Rooms </div>

         
        <div class="card-body">
          <div class="table-responsive">
			    <form action="controller.php?action=delete" Method="POST">  					
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
					
				  <thead>
				  	<tr>
				  		<th> <input type="checkbox" name="chkall" id="chkall" onclick="return checkall('selector[]');"> Room Name</th>
				  		<th>Department Description</th>
				 
				  	</tr>	
				  </thead>
				  <tbody>
				  	<?php 
				  		$room = new Room();
						$cur = $room->listOfroom();
						foreach ($cur as $Room) {
				  		echo '<tr>';

				  		echo '<td><input type="checkbox" name="selector[]" id="selector[]" value="'.$Room->ROOM_ID. '"/>
				  				<a href="index.php?view=edit&id='.$Room->ROOM_ID.'">' . $Room->ROOM_NAME.'</a></td>';
				  		echo '<td colspan="3">'. $Room->ROOM_DESC.'</td>';
				  		echo '</tr>';
				  	} 
				  	?>
				  </tbody>	
				</table>
				<?php
				if($_SESSION['ACCOUNT_TYPE']=='Administrator'){
						echo '
				<div class="btn-group">
				  <a href="index.php?view=add" class="btn btn-primary"><span class="glyphicon glyphicon-plus-sign"></span> New</a>
				  <button type="submit" class="btn btn-danger delete" name="delete"><span class="glyphicon glyphicon-trash"></span> Delete Selected</button>
				</div>';
			}
				?>
				</form>

       </div>
        </div>
      
      </div>