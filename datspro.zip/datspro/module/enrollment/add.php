<?php 
if (!isset($_SESSION['ACCOUNT_ID'])){
 redirect(web_root."admin/index.php");
 }


?> 


<div class="container">
    <div class="card card-register mx-auto mt-2">
      <div class="card-header">Add Enrollment</div>
      <div class="card-body"> 
 <ol class="breadcrumb">
         <form class="form-inline my-2 my-lg-0 mr-lg-2" action="index.php?view=add" method="POST">
            <div class="input-group">
              <input class="form-control" type="text"  name="txtsearch" placeholder="Enter LRN">
              <span class="input-group-append">
                <button class="btn btn-primary" type="submit" name="search">
                  <i class="fa fa-search"></i>
                </button>
              </span>
            </div>
          </form>
          <?php
              if (isset($_POST['search'])){
              if ($_POST['txtsearch']==""){
                echo "ID Number is required!";
                
              }else{
                $mydb->setQuery("SELECT * FROM `tblstudent` WHERE `IDNO`='{$_POST['txtsearch']}' AND IDNO NOT IN (SELECT `IDNO` FROM `schoolyr` WHERE `SEMESTER`='{$_SESSION['SEMESTER']}' AND  `AY`='{$_SESSION['AY']}')");
                $rowcount = $mydb->num_rows();
               if ($rowcount==1){

                $student = new Student();
                $cur = $student->single_student($_POST['txtsearch']);
                echo "Found 1 student!";
               } else{
                 echo "ID Number not found!";
                // redirect("index.php?view=add");
               }

             
              }
            }
           
            ?>
      </ol>
 <form action="controller.php?action=add" method="POST">

               <div class="form-group">
                    <div class="form-row">
                      <div class="col-md">
                      <label for="datetoday">Date</label>
                        <?php
                         date_default_timezone_set('Asia/Manila'); 
                          
                         $created =  strftime("%Y-%m-%d %H:%M:%S", time()); 
                       ?>
                         <input class="form-control input-sm" id="datetoday" readonly name="datetoday" placeholder=
                            "Date Today" type="text" value="<?php  echo date_toText($created); ?>">
                      </div>
                    </div>
                  </div>



                  <div class="form-group">
                    <div class="form-row">
                      <div class="col-md">
                      <label for="Idnum">ID Number:</label>
                        <input name="Idnum" type="hidden" value="">
                         <input class="form-control input-sm" id="Idnum" readonly name="Idnum" placeholder=
                            "ID Number" type="text" value="<?php echo (isset($cur)) ? $cur->IDNO : '' ;?>" required >
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                   <div class="form-row">
                      <div class="col-md">
                      <label for=
                      "studname">Student Name:</label>

                        <input class="form-control input-sm" id="studname" readonly name="studname" placeholder=
                            "Student Name" type="text" value="<?php echo (isset($cur)) ? $cur->LNAME.', '.$cur->FNAME : '' ;?>" required>
                      </div>
                    </div>
                  </div>
                   <div class="form-group">
                     <div class="form-row">
                      <div class="col-md">
                      <label for=
                      "Status">Status : </label>

                         <select class="form-control input-sm" name="Status" id="Status">
                            <option value="New">New Student</option>
                            <option value="Continuing">Continuing</option>  
                            <option value="Trasferee">Trasferee</option>  
                          </select>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                 <div class="form-row">
                      <div class="col-md-8">
                      <label for=
                      "grdlvl">Grade Level</label>

                          <select class="form-control input-sm" name="grdlvl" id="grdlvl">
                            <?php
                            global $mydb;
                             $mydb->setQuery("SELECT `COURSE_ID`, CONCAT(`COURSE_NAME`,'-', `COURSE_LEVEL`) as 'COURSE' FROM `course`"); 
                             $cur = $mydb->loadResultList();
                            foreach ($cur as $Department) {
                              echo '<option value="'. $Department->COURSE_ID.'">'.$Department->COURSE .'</option>';
                            }

                            ?>
                    
                           </select> 
                      </div>
                      <div class="col-md-4">
                      <label for=
                      "Section">Section</label>

                          <select class="form-control input-sm" name="Section" id="Section">
                            <option value="A">A</option>
                            <option value="B">B</option>  
                            <option value="C">C</option>  
                            <option value="D">D</option>  
                            <option value="E">E</option>  
                            <option value="F">F</option>  
                           </select> 
                      </div>
                    </div>
                  </div>
                 <div class="form-group">
                     <div class="form-row">
                      <div class="col-md">
                      <label for="sem" >Semester :</label>
                      <input type="text" class="form-control input-sm" name="sem" id="sem" value="<?php echo $_SESSION['SEMESTER']; ?>" readonly >
                       
                      </div>
                    </div>
                  </div>   
                 
                  <div class="form-group">
                    <div class="form-row">
                      <div class="col-md">
                      <label  for=
                      "ay">Academic Year :</label>
                        <input type="text" class="form-control input-sm" name="ay" id="ay" value="<?php echo $_SESSION['AY']; ?>" readonly>
                        
                      </div>
                    </div>
                  </div>   
            
                   <button class="btn btn-primary btn-block" name="save" type="submit" ><span class="glyphicon glyphicon-floppy-save"></span> Save Enrollment</button>





              
        </form>
                  
      </div>
    </div>
  </div>
 