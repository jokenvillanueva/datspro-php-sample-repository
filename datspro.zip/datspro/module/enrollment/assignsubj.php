<?php 
  if (!isset($_SESSION['ACCOUNT_ID'])){
   redirect(web_root."admin/index.php");
   }

   $id = $_GET['id'];
 //  $mydb->setQuery("SELECT `SYID`, `AY`, `SEMESTER`, schoolyr.`COURSE_ID`, `IDNO`, `CATEGORY`, `DATE_RESERVED`, `DATE_ENROLLED`, `STATUS`, `STUDENTNAME`,CONCAT(`COURSE_NAME`,'- ', `COURSE_LEVEL`) as 'COURSENAME' FROM `schoolyr` LEFT JOIN course ON schoolyr.COURSE_ID = course.COURSE_ID and IDNO='{$syid}' LIMIT 1");
 //  $cur = $mydb->loadsingleResult();
    $sy = new Schoolyr();
    $cur = $sy->single_sy($id);

?>

<form  action="controller.php?action=Assign" method="POST">   
<div class="row">
  <div class="col-lg-4">
 <div class="card mb-3">
  <div class="card-header">
              <i class="fa fa-bar-chart"></i> Student Details</div>
      <div class="card-body">
              <div class="form-group">
                <div class="form-row">
                    <div class="col-md">
                   <label  for="Idnum">ID Number:</label>
                     <input type="text" hidden name="selector" value="">
                    <input name="syid" type="hidden" value="<?php echo $SYID; ?>">
                     <input class="form-control input-sm" id="Idnum" readonly name="Idnum" placeholder=
                        "ID Number" type="text" value="<?php echo (isset($cur)) ? $cur->IDNO : 'IDNO' ;?>">
                </div>
              </div>
            </div>
            <div class="form-group">
             <div class="form-row">
                    <div class="col-md">
                <label  for="studname">Student Name:</label>

                  <input class="form-control input-sm" id="studname" readonly name="studname" placeholder=
                      "Student Name" type="text" value="<?php echo (isset($cur)) ? $cur->STUDENTNAME : 'Fullname' ;?>">
                </div>
              </div>
            </div>
             <div class="form-group">
               <div class="form-row">
                    <div class="col-md">
                <label  for="Status">Status : </label>

                <input class="form-control input-sm" id="studname" readonly name="Status" placeholder=
                      "Student Name" type="text" value="<?php echo (isset($cur)) ? $cur->STATUS : 'Status' ;?>">
                   
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="form-row">
                    <div class="col-md">
                <label for="grdlvl">Strand/Yr :</label>

                  <?php
                  $course = new Course();
                  $object = $course->single_course($cur->COURSE_ID);
                  ECHO '<input class="form-control input-sm" id="studname" readonly name="grdlvl" placeholder=
                                              "Student Name" type="text" value="'. $object->COURSE_NAME .'- '. $object->COURSE_LEVEL .'">';
                  ?>

                  
                   
                </div>
              </div>
            </div>
             <div class="form-group">
              <div class="form-row">
                  <div class="col-md">
                <label for=
                "section">Section : </label>

                
                <input class="form-control input-sm" id="section" readonly name="SECTION" placeholder=
                      "Semester" type="text" value="<?php echo (isset($cur)) ? $cur->SECTION : 'SECTION' ;?>">
                   
                </div>
              </div>
            </div>
   
            <div class="form-group">
              <div class="form-row">
                  <div class="col-md">
                <label for=
                "SEMESTER">Semester : </label>

                
                <input class="form-control input-sm" id="SEMESTER" readonly name="SEMESTER" placeholder=
                      "Semester" type="text" value="<?php echo (isset($cur)) ? $cur->SEMESTER : 'SEMESTER' ;?>">
                   
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="form-row">
                    <div class="col-md">
                <label  for="ay">A.Y :</label>

                  <input class="form-control input-sm" id="ay" readonly name="ay" placeholder=
                      "Academic Year" type="text" value="<?php echo (isset($cur)) ? $cur->AY : 'AY' ;?>">
                
                </div>
              </div>
            </div>
    </div>    
  </div>
  </div>
 <div class="col-lg-8">
  <div class="card mb-3">
  <div class="card-header">
      <i class="fa fa-bar-chart"></i> Subject Details</div>
      <div class="card-body">
     <div class="table-responsive">     
                <table id="dataTable" cellspacing="0" class="table table-striped table-bordered table-hover table-responsive" style="font-size:12px" cellspacing="0">
                
                  <thead>
                    <tr>
                      <th>
                         <input type="checkbox" name="chkall" id="chkall" onclick="return checkall('selector[]');"> 
                      ID</th>
                      <th>Code</th>
                      <th>Description</th>
                      <th>Unit</th>
                      <th>Time</th>
                      <th>Room</th>
                      <th>Day</th>
                       <th>Faculty</th>
                   
                 
                    </tr> 
                  </thead> 
                  <tbody>
                  
                    <?php 
                    global $mydb;
                      // `SUBJ_ID`, `SUBJ_CODE`, `SUBJ_DESCRIPTION`, `UNIT`, `PRE_REQUISITE`, `COURSE_ID`, `AY`, `SEMESTER`
                      $mydb->setQuery("SELECT  s.`SUBJ_ID` , s.SUBJ_CODE, s.SUBJ_DESCRIPTION, s.UNIT, C.INST_ID, C.C_TIME, C.DAY, C.ROOM, C.INST_NAME FROM  `subject` s left join class c ON s.`SUBJ_ID` = c.SUBJ_ID  where  s.COURSE_ID='". $cur->COURSE_ID."' AND s.SEMESTER='{$cur->SEMESTER}' AND s.SUBJ_ID NOT IN(SELECT g.`SUBJ_ID` FROM `grades` g WHERE `IDNO`='{$_GET['id']}' AND g.`AY`='{$_SESSION['AY']}' AND g.`SEMESTER`='{$_SESSION['SEMESTER']}')");
                  /*      SELECT * 
                              FROM  `subject`s, `class` c where s.`SUBJ_ID`=c.`SUBJ_ID` AND  COURSE_ID='". $cur->COURSE_ID."' AND SEMESTER='{$cur->SEMESTER}' AND SUBJ_ID NOT IN(SELECT `SUBJ_ID`FROM `grades` WHERE `IDNO`='{$_GET['id']}' AND `AY`='{$_SESSION['AY']}' AND `SEMESTER`='{$_SESSION['SEMESTER']}')");*/
                      $rowcount = $mydb->num_rows();
                    //  echo $rowcount;
                      if ($rowcount == 0){
                          echo '<tr>';
                          echo '<td colspan="5" align="center"> All Subjects has been assigned!</td>';
                          echo '</tr>';
                      }else{
                        $SUBJ = $mydb->loadResultList();

                        foreach ($SUBJ as $result) {
                          echo '<tr>';
                          // echo '<td width="5%" align="center"></td>';
                          echo '<td><input type="checkbox" name="selector[]" id="selector[]"  value="' . $result->SUBJ_ID.'"/>' . $result->SUBJ_ID.'</a></td>';
                          echo '<td>' . $result->SUBJ_CODE.'</a></td>';
                          echo '<td>'. $result->SUBJ_DESCRIPTION.'</td>';
                          echo '<td>'. $result->UNIT.'</td>';
                           echo '<td>'. $result->C_TIME.'</td>';
                            echo '<td>'. $result->ROOM.'</td>';
                             echo '<td>'. $result->DAY.'</td>';
                           echo '<td>'. $result->INST_NAME.'</td>';
                          echo '</tr>';
                        } 
                      }
                      
                    ?>
                  </tbody>
                  
                </table>
       </div>
       <button type="submit" class="btn btn-default" name="Assign"  ><span class="glyphicon glyphicon-bookmark"></span> Assign Subjects</button>

  </div>

</div> 
</div>
</div>

       
</form>