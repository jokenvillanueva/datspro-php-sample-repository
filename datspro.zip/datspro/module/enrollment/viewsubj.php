                      <?php 
                        if (!isset($_SESSION['ACCOUNT_ID'])){
                         redirect(web_root."admin/index.php");
                         }

                 
                       ?> 
<?php
     $syid = $_GET['id'];
          $sy = new Schoolyr();
          $cur = $sy->single_sy($syid);
      
      ?>
<script type="text/javascript">
  $(document).ready(function() {
    $('#examples').DataTable( {
      paging:         false
    } );
} );
</script>

 <form class="form-horizontal" action="controller.php?action=Assign" method="POST">  
<div class="row">
  <div class="col-lg-4">
     <div class="card mb-3">

      <div class="card-header">
              <i class="fa fa-bar-chart"></i> Student Details
      </div>
      
        <div class="card-body">
           <div class="form-group">
            <div class="form-row">
                    <div class="col-md">
               <label  for="Idnum">ID Number:</label>

                 <input type="text" hidden name="selector" value="">
                <input name="syid" type="hidden" value="<?php echo $syid; ?>">
                 <input class="form-control input-sm" id="Idnum" readonly name="Idnum" placeholder=
                    "ID Number" type="text" value="<?php echo (isset($cur)) ? $cur->IDNO : 'IDNO' ;?>">
              </div>
            </div>
          </div>

                  <div class="form-group">
                   <div class="form-row">
                    <div class="col-md">
                      <label  for="studname">Student Name:</label>

                    
                        <input class="form-control input-sm" id="studname" readonly name="studname" placeholder=
                            "Student Name" type="text" value="<?php echo (isset($cur)) ? $cur->STUDENTNAME : 'Fullname' ;?>">
                      </div>
                    </div>
                  </div>
                   <div class="form-group">
                     <div class="form-row">
                    <div class="col-md">
                      <label  for="Status">Status : </label>

                      <input class="form-control input-sm" id="studname" readonly name="Status" placeholder=
                            "Student Name" type="text" value="<?php echo (isset($cur)) ? $cur->STATUS : 'Status' ;?>">
                         
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                  <div class="form-row">
                    <div class="col-md">
                      <label  for=
                      "grdlvl">Strand/Yr :</label>

                        <?php
                        $course = new Course();
                        $object = $course->single_course($cur->COURSE_ID);
                        ECHO '<input class="form-control input-sm" id="studname" readonly name="grdlvl" placeholder=
                                                    "Student Name" type="text" value="'. $object->COURSE_NAME .'- '. $object->COURSE_LEVEL .'">';
                        ?>

                        
                         
                      </div>
                    </div>
                  </div>
                    <div class="form-group">
                  <div class="form-row">
                    <div class="col-md">
                      <label  for=
                      "grdlvl">Section :</label>

                       <input class="form-control input-sm" id="section" readonly name="section" placeholder=
                            "section" type="text" value="<?php echo (isset($cur)) ? $cur->SECTION : 'SECTION' ;?>">
                        
                         
                      </div>
                    </div>
                  </div>
                 
                  <div class="form-group">
                     <div class="form-row">
                    <div class="col-md">
                      <label  for=
                      "section">Semester : </label>

                     
                      <input class="form-control input-sm" id="section" readonly name="SEMESTER" placeholder=
                            "Semester" type="text" value="<?php echo (isset($cur)) ? $cur->SEMESTER : 'SEMESTER' ;?>">
                         
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                   <div class="form-row">
                    <div class="col-md">
                      <label  for="ay">A.Y :</label>

                        <input class="form-control input-sm" id="ay" readonly name="ay" placeholder=
                            "Academic Year" type="text" value="<?php echo (isset($cur)) ? $cur->AY : 'AY' ;?>">
                      
                      </div>
                    </div>
                  </div>  
        </div>
    </div> 

  </div>
  <div class="col-lg-8">
    <div class="card mb-3">

      <div class="card-header">
              <i class="fa fa-bar-chart"></i> Student Subjects
      </div>
      
        <div class="card-body">
             <div class="table-responsive">     
        <table id="dataTables"  class="table table-striped table-bordered table-hover table-responsive" style="font-size:12px" cellspacing="0">
        
          <thead>
            <tr>
              <th width="20%">Subject ID</th>
              <th width="80%">Description</th>
            
         
            </tr> 
          </thead> 
          <tbody>
          
            <?php 
            global $mydb;
              // $mydb->setQuery("SELECT * 
                //      FROM  `tblusers` WHERE TYPE != 'Customer'");
              $mydb->setQuery("SELECT g.`SUBJ_ID`, g.`DESCRIPTION`, `INSTNAME` FROM `grades` g  LEFT JOIN `instructorssubjects` i ON g.`AY`=i.`AY` and g.`SEMESTER`=i.`SEMESTER` AND g.SUBJ_ID=i.SUBJ_ID WHERE IDNO ='{$cur->IDNO}' AND g.`AY`='{$_SESSION['AY']}' AND g.`SEMESTER`='{$_SESSION['SEMESTER']}' GROUP BY g.`SUBJ_ID` ");
                $rowcount = $mydb->num_rows();
                   //   echo $rowcount;
                      if ($rowcount == 0){
                          echo '<tr>';
                          echo '<td colspan=3 align="center"> No Subjects has been assigned!</td>';
                          echo '</tr>';
                      }else{
                          $cur = $mydb->loadResultList();
                          foreach ($cur as $result) {
                            echo '<tr>';
                            // echo '<td width="5%" align="center"></td>';
                            echo '<td>' . $result->SUBJ_ID.'</a></td>';
                            echo '<td>' . $result->DESCRIPTION.'</a></td>';
                          //  echo '<td>'. $result->INSTNAME.'</td>';
                            echo '</tr>';
                          } 

                      }
            ?>
          </tbody>
          
        </table>
 
       
 
      </div>
        </div>
    </div> 
  </div>
  
</div>

       
</form>