<?php
	 if (!isset($_SESSION['ACCOUNT_ID'])){
      redirect(web_root."admin/index.php");
     }

?>
 <script type="text/javascript"> 
$('search').click(function() {
  $(this).focus();
})
   </script> 

 <div class="row">
  <div class="col-lg-8">
  <div class="card-header"> 
  <form class="form-inline my-2 my-lg-0 mr-lg-2" action="#" method="POST">
    <label for="search">Scan or Enter Your ID  here :   </label>
    <div class="input-group">
      <input class="form-control action" type="text" id="search"  name="txtsearch" autofocus placeholder="LRN or RFID...">
      <span class="input-group-append">
        <button class="btn btn-primary" type="submit" name="search">
          <i class="fa fa-search"></i>
        </button>
      </span>
    </div>
  </form>
		<?php
            if (isset($_POST['search'])){
              if ($_POST['txtsearch']==""){
                echo "ID Number is required!";
                
              }else{
                $mydb->setQuery("SELECT * FROM `schoolyr` WHERE `SEMESTER`='{$_SESSION['SEMESTER']}' AND  `AY`='{$_SESSION['AY']}' AND IDNO='{$_POST['txtsearch']}'");
               //  $cur = $mydb->loadSingleResult();
                unset($_SESSION['message']);
	 			unset($_SESSION['msgtype']);
                $rowcount = $mydb->num_rows();
	               if ($rowcount==1){
	               	//message("Found 1 student","success");
			 		/*	$student = new Student();
		                $cur = $student->single_student($_POST['txtsearch']);*/
		                $student = new Student();
		                $cur = $student->single_student_attendance($_SESSION['AY'], $_SESSION['SEMESTER'], $_POST['txtsearch']);

	                	

	                $mydb->setQuery("INSERT INTO `tbldtr` (`DTRID`, `MEMBERID`, `AMLOGIN`, `AMLOGOUT`, `PMLOGIN`, `PMLOGOUT`, `CURRENTDATE`) VALUES ('', '1221345', '02:00:00', '02:07:00', '07:18:12', '03:24:03', '2018-11-27');");
	                $mydb->executeQuery();
	                               
	               } else{
	                //  message("Student not found!","error");
	                // redirect("index.php?view=add");
	               }

             
              }
            }
           
            ?>

      </div>
      	<div class="row">
  			<div class="col-lg-4">
  				<div class="card-body">
       			<?php
       			if (isset($_POST['txtsearch'])) {
       				$mydb->setQuery("SELECT * FROM PHOTO WHERE IDNO IN (SELECT IDNO FROM `schoolyr` WHERE `SEMESTER`='{$_SESSION['SEMESTER']}' AND  `AY`='{$_SESSION['AY']}' AND IDNO='{$_POST['txtsearch']}')");

				$rowcount1 = $mydb->num_rows();
				if ($rowcount1 > 0){
				 
				 $curz= $mydb->loadSingleResult();
				 $location = $curz->FILENAME;
				echo '<img src="../student/'. $location .'" width="200" height="200" />';
				}else{
					$location = '../student/photos/defaultimg.png';
					echo '<img src="'. $location .'" width="200" height="200" />';
				}

       			
       			}else{
       				$location = '../student/photos/defaultimg.png';
					echo '<img src="'. $location .'" width="200" height="200" />';
       			}
       			

       			?>	
      	
         
  				</div> 
  			</div>
  			<div class="col-lg-8">
  				<div class="card-body">

  				<table  class="dash-table" width="100%" border="0">

  	
  					<tr>
  						<td>LRN :</td><td ><?php echo (isset($cur)) ? $cur->LRN : '' ;?></td>
  					</tr>
  					<tr>
  						<td>NAME :</td><td><?php echo (isset($cur)) ? $cur->Name  : '' ;?></td>
  					</tr>
  					<tr>
  					<?php

  					if (isset($cur)) {
  						$course = new Course();
                  		$object = $course->single_course($cur->COURSE_ID);
                  		echo	'<td>GRADE/LEVEL :</td><td>'. $object->COURSE_NAME .'- '. $object->COURSE_LEVEL .'</td>';
  					}
                  
                 
                  ?> 
  					
  					</tr>
  					
  					<tr>
  						<td>CONTACT PERSON :</td><td><?php echo (isset($cur)) ? $cur->FATHER : '' ;?></td>
  					</tr>
  					<tr>
  						<td>CONTACT NUMBER :</td><td><?php echo (isset($cur)) ? $cur->CONTACTPERSON : '' ;?></td>
  					</tr>
  				</table>
				</div>
  			</div>
  		</div>	
      
  </div>
 </div> 
<div class="card mb-3">

        <div class="card-header">
          <i class="fa fa-table"></i> List of Attendance  </div>

         
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
      			
				
				  <thead>
				  	<tr>
				  		
				  		  <th>STUDENT LRN</th>
				  		  <th>AM IN</th>
				  		  <th>AM OUT</th>
				  		  <th>PM IN</th>
				  		  <th>PM OUT</th>
				  		  <th>DATE</th>
				  		
				  	</tr>	
				  </thead> 
				  <tbody>
				  	<?php 
				  	//`DTRID`, `MEMBERID`, `AMLOGIN`, `AMLOGOUT`, `PMLOGIN`, `PMLOGOUT`, `CURRENTDATE`
				  		$Attendance = new Attendance();
						$att = $Attendance->listofattendance();
						foreach ($att as $dtr) {
				  		echo '<tr>';

				  		echo '<td>' . $dtr->MEMBERID.'</a></td>';
				  		echo '<td>'. $dtr->AMLOGIN.'</td>';
				  		echo '<td>'. $dtr->AMLOGOUT.'</td>';
				  		echo '<td>'. $dtr->PMLOGIN.'</td>';
				  		echo '<td>'. $dtr->PMLOGOUT.'</td>';
				  		echo '<td>'. $dtr->CURRENTDATE.'</td>';
				  		
				  		echo '</tr>';
				  	} 
				  	?>
				  </tbody>
					
				</table>
		      </div>
        </div>
      
      </div>