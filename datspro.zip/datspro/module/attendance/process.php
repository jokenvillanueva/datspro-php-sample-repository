<?php
require_once("../../include/initialize.php");

if(isset($_POST["action"]))
{
 //echo //htmlentities($_POST['query']);
 $output = '';

 if($_POST["action"] == "province")
 {
  global $mydb;
  $mydb->setQuery("SELECT DISTINCT(`CITY`) FROM `tblplace` WHERE `PROVINCE`='". ($_POST['query'])."'");
  $cur = $mydb->loadResultList();
  $output .= '<option value="">Select City/Municipalities/Town</option>';
  foreach ($cur as $prov) {
       $output .= '<option value="'. utf8_encode($prov->CITY).'">'.utf8_encode($prov->CITY).'</option>';
    }
   }



}
?>