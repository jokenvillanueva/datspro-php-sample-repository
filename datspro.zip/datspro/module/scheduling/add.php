                      <?php 
                        if (!isset($_SESSION['ACCOUNT_ID'])){
                          redirect(web_root."admin/index.php");
                         }
                         
                         
                 
                       ?> 
  <div class="container">
    <div class="card card-register mx-auto mt-2">
      <div class="card-header"> New Schedule</div>
      <div class="card-body">                       
         <form action="controller.php?action=add" method="POST">

            
                <div class="form-group">
                  <div class="form-row">
                      <div class="col-md">
                  <label  for=
                  "subjcode">Subject Code</label>

                      <input type="hidden" name="subjid" >
                   
                           <select class="form-control input-sm" name="subjcode" id="subjcode">
                                  <?php

                                 
                        global $mydb;
                              $mydb->setQuery("SELECT * 
                                      FROM subject where COURSE_ID=".$_GET['cid']);

                              $s = $mydb->loadResultList();

                                  foreach ($s as $sbj) {
                                    echo '<option value="'. $sbj->SUBJ_ID.'">'.$sbj->SUBJ_CODE.'</option>';
                                  }

                                  ?>
                            
                          </select> 
                  </div>
                </div>
              </div>

              <div class="form-group">
                  <div class="form-row">
                      <div class="col-md">
                  <label for=
                  "day">Day</label>

                
                     <select class="form-control input-sm" name="day" id="day">
                                  <?php
                                                           
                            $room = new Room();
                            $day = $room->listOfDay();
                                
                                  foreach ($day as $d) {
                                    echo '<option value="'. $d->DAYDESC.'">'.$d->DAYDESC.'</option>';
                                  }

                                  ?>
                            
                          </select> 
                  </div>
                </div>
              </div>

               <div class="form-group">
                 <div class="form-row">
                      <div class="col-md">
                  <label  for=
                  "time">Time</label>

                     <select class="form-control input-sm" name="time" id="time">
                                  <?php
                                                           
                            $room = new Room();
                            $time = $room->listOfTime();
                                
                                  foreach ($time as $t) {
                                    echo '<option value="'. $t->TIMEDESC.'">'.$t->TIMEDESC.'</option>';
                                  }

                                  ?>
                            
                          </select> 
                  </div>
                </div>
              </div>
               <div class="form-group">
                <div class="form-row">
                      <div class="col-md">
                  <label for=
                  "room">Room</label>

                        <select class="form-control input-sm" name="room" id="room">
                                  <?php
                                                           
                            $room = new Room();
                            $rm = $room->listOfroom();
                                
                                  foreach ($rm as $r) {
                                    echo '<option value="'. $r->ROOM_NAME.'">'.$r->ROOM_NAME.'</option>';
                                  }

                                  ?>
                            
                          </select> 
                  </div>
                </div>
              </div>
              
               <div class="form-group">
                  <div class="form-row">
                      <div class="col-md">
                  <label  for=
                  "instructor">Instructor</label>
                <select class="form-control input-sm" name="instructor" id="instructor">
                                  <?php
                                                           
                            $singleinstructor = new Instructor();
                            $inst = $singleinstructor->listOfinstructor();
                                
                                  foreach ($inst as $i) {
                                    echo '<option value="'. $i->INST_ID.'">'.$i->INST_FULLNAME.'</option>';
                                  }

                                  ?>
                            
                          </select> 
                  </div>
                </div>
              </div>
           
          <?php
              if($_SESSION['ACCOUNT_TYPE']=='Administrator'){
                echo '<button class="btn btn-primary btn-block" name="savecourse" type="submit" >Save</button>';
              }
            ?>

            


                </form>
    </div>
    </div>
  </div>
  