<?php 
  if (!isset($_SESSION['ACCOUNT_ID'])){
    redirect(web_root."admin/index.php");
   }


 ?>
 <div class="container">
    <div class="card card-register mx-auto mt-2">
      <div class="card-header">New Faculty</div>
      <div class="card-body">          
 <form  action="controller.php?action=add" method="POST">

   
                              
                <div class="form-group">
                  <div class="form-row">
                      <div class="col-md">
                      <label  for="idno">Employee ID NO.:</label>

                         <input class="form-control " id="idno" name="idno" placeholder=
                            "Employee ID Number" type="text" value="" required>
                      </div>
                    </div>
                  </div>
              <div class="form-group">
                   <div class="form-row">
                        <div class="col-md">
                      <label  for="name">Fullname:</label>

                        
                         <input class="form-control input-sm" id="name" name="name" placeholder=
                            "Account Name" type="text" value="" required>
                      </div>
                    </div>
                  </div>

                  <div class="form-group">
                   <div class="form-row">
                        <div class="col-md">
                      <label for="address">Current Address:</label>

                        <input name="deptid" type="hidden" value="">
                         <input class="form-control input-sm" id="address" name="address" placeholder=
                            "Current Address" type="text" value="" required>
                      </div>
                    </div>
                  </div>

                  <div class="form-group">
                    <div class="form-row">
                        <div class="col-md">
                      <label for="Gender">Gender:</label>

                       <select class="form-control input-sm" name="Gender" id="Gender">
                          <option value="M">Male</option>
                          <option value="F">Female</option>
                          
                        </select> 
                      </div>
                    </div>
                  </div>

                  <div class="form-group">
                   <div class="form-row">
                        <div class="col-md">
                      <label  for="civilstats">Civil Status:</label>

                       <select class="form-control input-sm" name="civilstats" id="civilstats">
                          <option value="Single">Single</option>
                          <option value="Married">Married</option>
                          
                        </select> 
                      </div>
                    </div>
                  </div>

                  <div class="form-group">
                  <div class="form-row">
                        <div class="col-md">
                      <label for="specialization">Specialization:</label>

                    
                      
                         <input class="form-control input-sm" id="specialization" name="specialization" placeholder=
                            "Specialization" type="text" value="" required>
                      </div>
                    </div>
                  </div>

                  <div class="form-group">
                   <div class="form-row">
                        <div class="col-md">
                      <label for="empStats">Employment Status:</label>
                           <input class="form-control input-sm" id="empStats" name="empStats" placeholder=
                            "Employment Status" type="text" value="" required>
                      </div>
                    </div>
                  </div>
                  


            <div class="form-group">
                   <div class="form-row">
                        <div class="col-md">
                      <label for="email">Email Address:</label>
                          <input class="form-control" id="email" name="email" placeholder=
                            "Email Address" type="email" value="" required>
                      </div>
                    </div>
                  </div>
 <button class="btn btn-primary btn-block" name="save" type="submit" ><span class="glyphicon glyphicon-floppy-save"></span> Save Faculty</button>

            
                          
       
          
        </form>
            
      </div>
    </div>
  </div>
 