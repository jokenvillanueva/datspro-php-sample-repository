<?php  
      if (!isset($_SESSION['ACCOUNT_ID'])){
      redirect(web_root."admin/index.php");
     }

  @$COURSEID = $_GET['id'];
    if($COURSEID==''){
  redirect("index.php");
}
  $Course = New Course();
  $singleCOURSE = $Course->single_course($COURSEID);

?> 
 <div class="container">
    <div class="card card-register mx-auto mt-2">
      <div class="card-header">Update Strand Details</div>
      <div class="card-body">   
 <form action="controller.php?action=edit&id=<?php echo (isset($singleCOURSE)) ? $singleCOURSE->COURSE_ID : '' ;?>"" method="POST">

                   
                  <div class="form-group">
                   <div class="form-row">
                        <div class="col-md">
                      <label  for="coursename">Strand Name:</label>
                          <input class="form-control input-sm" id="coursename" name="coursename" placeholder=
                            "Course Name" type="text" value="<?php echo $singleCOURSE->COURSE_NAME; ?>" required>
                      </div>
                    </div>
                  </div>

                   <div class="form-group">
                     <div class="form-row">
                        <div class="col-md">
                      <label for="level">Grade:</label>
                       
                         <input class="form-control input-sm" id="level" name="level" placeholder=
                            "Level" type="number" value="<?php echo $singleCOURSE->COURSE_LEVEL; ?>" required>
                      </div>
                    </div>
                  </div>
                  <!--  <div class="form-group">
                    <div class="form-row">
                        <div class="col-md">
                      <label  for=
                      "major">Section:</label>
                        <input class="form-control input-sm" id="major" name="major" placeholder=
                            "Major" type="text" value="<?php echo $singleCOURSE->COURSE_MAJOR; ?>" required>
                      </div>
                    </div>
                  </div> -->
                   <div class="form-group">
                    <div class="form-row">
                        <div class="col-md">
                      <label  for=
                      "coursedesc">Description:</label>

                        <input class="form-control input-sm" id="coursedesc" name="coursedesc" placeholder=
                            "Description" type="text" value="<?php echo $singleCOURSE->COURSE_DESC; ?>" required>
                      </div>
                    </div>
                  </div>
                  


  <button class="btn btn-primary btn-block" name="savecourse" type="submit" ><span class="glyphicon glyphicon-floppy-save"></span> Update Strand</button>

          
        </form>
      
      </div>
    </div>
  </div>
 